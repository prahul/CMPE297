#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
/* Replace this with your name */
#define author "Rahul Priyadarshi"
#define __NR_helloworld 337
main(){
int retval;
printf("About to call the new helloworld() system call\n");
retval = syscall(__NR_helloworld, author, strlen(author));
printf("Done calling helloworld()\n");
printf("Your helloworld() system call returned the value %d\n", retval);
}
